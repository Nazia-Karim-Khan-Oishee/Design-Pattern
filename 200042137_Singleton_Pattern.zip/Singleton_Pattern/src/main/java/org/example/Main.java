package org.example;

public class Main {
    public static void main(String[] args) {


       // LibraryCatalog newcatalog = new LibraryCatalog();
        LibraryCatalog catalog = LibraryCatalog.getInstance();

        catalog.searchForBook("Head First Design Patterns");
        catalog.checkoutBook("Head First Design Patterns","Nazia");
        catalog.returnBook("Head First Design Patterns","Nazia");
        }
    }
