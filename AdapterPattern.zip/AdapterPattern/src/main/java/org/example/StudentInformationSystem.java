package org.example;

public interface StudentInformationSystem {

        void RetrievingStudentType(String name);
        void RetrievingStudentsProgramme(String name);

}
