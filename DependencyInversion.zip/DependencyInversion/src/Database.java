public interface Database {
    public void persist(String data);
}
