package org.example;

class GradingonAttendance implements GradingStrategy {
    @Override
    public String viewgrade() {
        return "Your grade for Attendance is A+";

    }
}
