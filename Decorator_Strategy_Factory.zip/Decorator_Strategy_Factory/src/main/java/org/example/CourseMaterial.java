package org.example;

public interface CourseMaterial {
    String getDescription();
}