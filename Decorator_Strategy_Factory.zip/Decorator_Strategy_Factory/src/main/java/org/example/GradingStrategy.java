package org.example;

interface GradingStrategy {
    String viewgrade();
}
